# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /tmp/torchinductor_root/f6/cf6auel6vjtdim5ppiqr3zq5xcyw2dcnyw5sagy7edpx2ku7envx.py
# Topologically Sorted Source Nodes: [x_padded, abs_1, amax, x_amax, sf, abs_2, log2, ceil, sf_1], Original ATen: [aten.zeros, aten.view, aten.abs, aten.amax, aten.clamp, aten.div, aten.log2, aten.ceil, aten.pow]
# Source node to ATen node mapping:
#   abs_1 => abs_1, view_1
#   abs_2 => abs_2
#   amax => amax
#   ceil => ceil
#   log2 => log2
#   sf => div
#   sf_1 => pow_1
#   x_amax => clamp_min
#   x_padded => full
# Graph fragment:
#   %arg2_1 : Tensor "f32[s77, s27][s27, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %amax : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][-((s27//(-s87))), ((s27//(-s87)))*((s77//(-s61))), 1, ((s27//(-s87)))*((s77//(-s61)))]cuda:0" = PlaceHolder[target=amax]
#   %full : Tensor "f32[-s61*((s77//(-s61))), -s87*((s27//(-s87)))][Max(1, -s87*((s27//(-s87)))), 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.full.default](args = ([%mul, %mul_1], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: cuda:0, pin_memory: False})
#   %slice_scatter_default : Tensor "f32[-s61*((s77//(-s61))), -s87*((s27//(-s87)))][Max(1, -s87*((s27//(-s87)))), 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%full, %arg2_1, 0, 0, %arg0_1), kwargs = {})
#   %view_1 : Tensor "f32[-((s77//(-s61))), s61, -((s27//(-s87))), s87][s61*Max(1, -s87*((s27//(-s87)))), Max(1, -s87*((s27//(-s87)))), s87, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%slice_scatter_default, [-1, %arg3_1, %neg_3, %arg4_1]), kwargs = {})
#   %abs_1 : Tensor "f32[-((s77//(-s61))), s61, -((s27//(-s87))), s87][Max(1, s61)*Max(1, s87)*Max(1, -((s27//(-s87)))), Max(1, s87)*Max(1, -((s27//(-s87)))), Max(1, s87), 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%view_1,), kwargs = {})
#   %amax : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), -((s27//(-s87))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%abs_1, [1, 3], True), kwargs = {})
#   %clamp_min : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%amax, 0.0001), kwargs = {})
#   %div : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%clamp_min, 448.0), kwargs = {})
#   %abs_2 : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%div,), kwargs = {})
#   %log2 : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.log2.default](args = (%abs_2,), kwargs = {})
#   %ceil : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.ceil.default](args = (%log2,), kwargs = {})
#   %pow_1 : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.pow.Scalar](args = (2.0, %ceil), kwargs = {})
#   return %amax,%pow_1
triton_red_fused_abs_amax_ceil_clamp_div_log2_pow_view_zeros_0 = async_compile.triton('triton_red_fused_abs_amax_ceil_clamp_div_log2_pow_view_zeros_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 2048, 'r0_': 16384},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'ks0': 'i64', 'ks1': 'i64', 'ks2': 'i64', 'ks3': 'i64', 'ks4': 'i64', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=148, cc=103, major=10, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_red_fused_abs_amax_ceil_clamp_div_log2_pow_view_zeros_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 1, 'backend_hash': '14902427B4EAA00E03F37BD9A4AC37B803D52FB315473AEC448643748601AB78', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'tiling_scores': {'x': 24576, 'r0_': 100663296}}
)
@triton.jit
def triton_red_fused_abs_amax_ceil_clamp_div_log2_pow_view_zeros_0(in_ptr0, out_ptr0, out_ptr1, ks0, ks1, ks2, ks3, ks4, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x1 = xindex // ks1
    x0 = (xindex % ks1)
    _tmp8 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    x4 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_3 = triton_helpers.div_floor_integer(r0_index,  ks0)
        r0_2 = (r0_index % ks0)
        tmp0 = r0_3 + ks2*x1
        tmp1 = ks3
        tmp2 = tmp0 < tmp1
        tmp3 = tl.load(in_ptr0 + (r0_2 + ks0*x0 + ks4*r0_3 + ks2*ks4*x1), r0_mask & tmp2 & xmask, eviction_policy='evict_last', other=0.0)
        tmp4 = tl.full([1, 1], 0.0, tl.float32)
        tmp5 = tl.where(tmp2, tmp3, tmp4)
        tmp6 = tl_math.abs(tmp5)
        tmp7 = tl.broadcast_to(tmp6, [XBLOCK, R0_BLOCK])
        tmp9 = triton_helpers.maximum(_tmp8, tmp7)
        _tmp8 = tl.where(r0_mask & xmask, tmp9, _tmp8)
    tmp8 = triton_helpers.max2(_tmp8, 1)[:, None]
    tl.store(out_ptr0 + (x4), tmp8, xmask)
    tmp10 = tl.full([1, 1], 0.0001, tl.float32)
    tmp11 = triton_helpers.maximum(tmp8, tmp10)
    tmp12 = tl.full([1, 1], 0.002232142857142857, tl.float32)
    tmp13 = tmp11 * tmp12
    tmp14 = tl_math.abs(tmp13)
    tmp15 = libdevice.log2(tmp14)
    tmp16 = libdevice.ceil(tmp15)
    tmp17 = libdevice.exp2(tmp16)
    tl.store(out_ptr1 + (x4), tmp17, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/y2/cy24bvm3mkl2bhm2enni62nw537f6phi45kuo647rsoxrouokjz2.py
# Topologically Sorted Source Nodes: [x_padded, abs_1, x_amax, sf, abs_2, log2, ceil, sf_1, truediv_1, mul_2, x_scaled], Original ATen: [aten.zeros, aten.view, aten.clamp, aten.div, aten.abs, aten.log2, aten.ceil, aten.pow, aten.reciprocal, aten.mul, aten._to_copy]
# Source node to ATen node mapping:
#   abs_1 => view_1
#   abs_2 => abs_2
#   ceil => ceil
#   log2 => log2
#   mul_2 => mul_53
#   sf => div
#   sf_1 => pow_1
#   truediv_1 => mul_49, reciprocal
#   x_amax => clamp_min
#   x_padded => full
#   x_scaled => convert_element_type
# Graph fragment:
#   %arg2_1 : Tensor "f32[s77, s27][s27, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %amax : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][-((s27//(-s87))), ((s27//(-s87)))*((s77//(-s61))), 1, ((s27//(-s87)))*((s77//(-s61)))]cuda:0" = PlaceHolder[target=amax]
#   %full : Tensor "f32[-s61*((s77//(-s61))), -s87*((s27//(-s87)))][Max(1, -s87*((s27//(-s87)))), 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.full.default](args = ([%mul, %mul_1], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: cuda:0, pin_memory: False})
#   %slice_scatter_default : Tensor "f32[-s61*((s77//(-s61))), -s87*((s27//(-s87)))][Max(1, -s87*((s27//(-s87)))), 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%full, %arg2_1, 0, 0, %arg0_1), kwargs = {})
#   %view_1 : Tensor "f32[-((s77//(-s61))), s61, -((s27//(-s87))), s87][s61*Max(1, -s87*((s27//(-s87)))), Max(1, -s87*((s27//(-s87)))), s87, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%slice_scatter_default, [-1, %arg3_1, %neg_3, %arg4_1]), kwargs = {})
#   %clamp_min : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%amax, 0.0001), kwargs = {})
#   %div : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%clamp_min, 448.0), kwargs = {})
#   %abs_2 : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%div,), kwargs = {})
#   %log2 : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.log2.default](args = (%abs_2,), kwargs = {})
#   %ceil : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.ceil.default](args = (%log2,), kwargs = {})
#   %pow_1 : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.pow.Scalar](args = (2.0, %ceil), kwargs = {})
#   %reciprocal : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%pow_1,), kwargs = {})
#   %mul_49 : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%reciprocal, 1.0), kwargs = {})
#   %mul_53 : Tensor "f32[-((s77//(-s61))), s61, -((s27//(-s87))), s87][Max(1, s61)*Max(1, s87)*Max(1, -((s27//(-s87)))), Max(1, s87)*Max(1, -((s27//(-s87)))), Max(1, s87), 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_1, %mul_49), kwargs = {})
#   %convert_element_type : Tensor "f8e4m3fn[-((s77//(-s61))), s61, -((s27//(-s87))), s87][Max(1, s61)*Max(1, s87)*Max(1, -((s27//(-s87)))), Max(1, s87)*Max(1, -((s27//(-s87)))), Max(1, s87), 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_53, torch.float8_e4m3fn), kwargs = {})
#   return %convert_element_type
triton_poi_fused__to_copy_abs_ceil_clamp_div_log2_mul_pow_reciprocal_view_zeros_1 = async_compile.triton('triton_poi_fused__to_copy_abs_ceil_clamp_div_log2_mul_pow_reciprocal_view_zeros_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 33554432}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'out_ptr0': '*fp8e4nv', 'ks0': 'i64', 'ks1': 'i64', 'ks2': 'i64', 'ks3': 'i64', 'ks4': 'i64', 'ks5': 'i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=148, cc=103, major=10, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_abs_ceil_clamp_div_log2_mul_pow_reciprocal_view_zeros_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'backend_hash': '14902427B4EAA00E03F37BD9A4AC37B803D52FB315473AEC448643748601AB78', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'tiling_scores': {'x': 150994944}},
    min_elem_per_thread=2
)
@triton.jit
def triton_poi_fused__to_copy_abs_ceil_clamp_div_log2_mul_pow_reciprocal_view_zeros_1(in_ptr0, in_ptr1, out_ptr0, ks0, ks1, ks2, ks3, ks4, ks5, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x5 = xindex // ks0
    x4 = (xindex % ks0)
    x1 = ((xindex // ks4) % ks3)
    x3 = xindex // ks5
    x6 = xindex
    tmp6 = tl.load(in_ptr1 + (x1 + (-1)*x3*(triton_helpers.div_floor_integer(ks2,  (-1)*ks4))), xmask, eviction_policy='evict_last')
    tmp0 = x5
    tmp1 = ks1
    tmp2 = tmp0 < tmp1
    tmp3 = tl.load(in_ptr0 + (x4 + ks2*x5), tmp2 & xmask, eviction_policy='evict_last', other=0.0)
    tmp4 = tl.full([1], 0.0, tl.float32)
    tmp5 = tl.where(tmp2, tmp3, tmp4)
    tmp7 = tl.full([1], 0.0001, tl.float32)
    tmp8 = triton_helpers.maximum(tmp6, tmp7)
    tmp9 = tl.full([1], 0.002232142857142857, tl.float32)
    tmp10 = tmp8 * tmp9
    tmp11 = tl_math.abs(tmp10)
    tmp12 = libdevice.log2(tmp11)
    tmp13 = libdevice.ceil(tmp12)
    tmp14 = libdevice.exp2(tmp13)
    tmp15 = tl.full([1], 1, tl.int32)
    tmp16 = (tmp15 / tmp14)
    tmp17 = tl.full([1], 1.0, tl.float32)
    tmp18 = tmp16 * tmp17
    tmp19 = tmp5 * tmp18
    tmp20 = tmp19.to(tl.float8e4nv)
    tl.store(out_ptr0 + (x6), tmp20, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/au/cauoy26jqlb3yebuaqqdj3k47mbc7upe2fkoyd4bqpr5mm4n23sy.py
# Topologically Sorted Source Nodes: [x_padded, abs_1, x_amax, sf, abs_2, log2, ceil, sf_1, truediv_1, mul_2, x_scaled, view_as, getitem_2], Original ATen: [aten.zeros, aten.view, aten.clamp, aten.div, aten.abs, aten.log2, aten.ceil, aten.pow, aten.reciprocal, aten.mul, aten._to_copy, aten.slice]
# Source node to ATen node mapping:
#   abs_1 => view_1
#   abs_2 => abs_2
#   ceil => ceil
#   getitem_2 => slice_6
#   log2 => log2
#   mul_2 => mul_53
#   sf => div
#   sf_1 => pow_1
#   truediv_1 => mul_49, reciprocal
#   view_as => view_2
#   x_amax => clamp_min
#   x_padded => full
#   x_scaled => convert_element_type
# Graph fragment:
#   %convert_element_type : Tensor "f8e4m3fn[-((s77//(-s61))), s61, -((s27//(-s87))), s87][-s61*s87*((s27//(-s87))), -s87*((s27//(-s87))), s87, 1]cuda:0" = PlaceHolder[target=convert_element_type]
#   %full : Tensor "f32[-s61*((s77//(-s61))), -s87*((s27//(-s87)))][Max(1, -s87*((s27//(-s87)))), 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.full.default](args = ([%mul, %mul_1], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: cuda:0, pin_memory: False})
#   %slice_scatter_default : Tensor "f32[-s61*((s77//(-s61))), -s87*((s27//(-s87)))][Max(1, -s87*((s27//(-s87)))), 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%full, %arg2_1, 0, 0, %arg0_1), kwargs = {})
#   %view_1 : Tensor "f32[-((s77//(-s61))), s61, -((s27//(-s87))), s87][s61*Max(1, -s87*((s27//(-s87)))), Max(1, -s87*((s27//(-s87)))), s87, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%slice_scatter_default, [-1, %arg3_1, %neg_3, %arg4_1]), kwargs = {})
#   %clamp_min : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%amax, 0.0001), kwargs = {})
#   %div : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%clamp_min, 448.0), kwargs = {})
#   %abs_2 : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%div,), kwargs = {})
#   %log2 : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.log2.default](args = (%abs_2,), kwargs = {})
#   %ceil : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.ceil.default](args = (%log2,), kwargs = {})
#   %pow_1 : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.pow.Scalar](args = (2.0, %ceil), kwargs = {})
#   %reciprocal : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%pow_1,), kwargs = {})
#   %mul_49 : Tensor "f32[-((s77//(-s61))), 1, -((s27//(-s87))), 1][Max(1, -((s27//(-s87)))), Max(1, -((s27//(-s87)))), 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%reciprocal, 1.0), kwargs = {})
#   %mul_53 : Tensor "f32[-((s77//(-s61))), s61, -((s27//(-s87))), s87][Max(1, s61)*Max(1, s87)*Max(1, -((s27//(-s87)))), Max(1, s87)*Max(1, -((s27//(-s87)))), Max(1, s87), 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_1, %mul_49), kwargs = {})
#   %convert_element_type : Tensor "f8e4m3fn[-((s77//(-s61))), s61, -((s27//(-s87))), s87][Max(1, s61)*Max(1, s87)*Max(1, -((s27//(-s87)))), Max(1, s87)*Max(1, -((s27//(-s87)))), Max(1, s87), 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_53, torch.float8_e4m3fn), kwargs = {})
#   %view_2 : Tensor "f8e4m3fn[-s61*((s77//(-s61))), -s87*((s27//(-s87)))][Max(1, s87)*Max(1, -((s27//(-s87)))), 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type, [%mul, %mul_1]), kwargs = {})
#   %slice_6 : Tensor "f8e4m3fn[s77, -s87*((s27//(-s87)))][Max(1, s87)*Max(1, -((s27//(-s87)))), 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%view_2, 0, 0, %arg0_1), kwargs = {})
#   return %slice_6
triton_poi_fused__to_copy_abs_ceil_clamp_div_log2_mul_pow_reciprocal_slice_view_zeros_2 = async_compile.triton('triton_poi_fused__to_copy_abs_ceil_clamp_div_log2_mul_pow_reciprocal_slice_view_zeros_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 33554432}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp8e4nv', 'out_ptr0': '*fp8e4nv', 'ks0': 'i64', 'ks1': 'i64', 'ks2': 'i64', 'ks3': 'i64', 'ks4': 'i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=148, cc=103, major=10, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_abs_ceil_clamp_div_log2_mul_pow_reciprocal_slice_view_zeros_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'backend_hash': '14902427B4EAA00E03F37BD9A4AC37B803D52FB315473AEC448643748601AB78', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'tiling_scores': {'x': 75497472}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_abs_ceil_clamp_div_log2_mul_pow_reciprocal_slice_view_zeros_2(in_ptr0, out_ptr0, ks0, ks1, ks2, ks3, ks4, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % ks0)
    x1 = xindex // ks0
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + (-1)*ks4*(triton_helpers.div_floor_integer(ks1,  (-1)*ks4))*((x1 % ((-1)*ks2*(triton_helpers.div_floor_integer(ks3,  (-1)*ks2)))))), xmask, eviction_policy='evict_last')
    tl.store(out_ptr0 + (x2), tmp0, xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1 = args
        args.clear()
        s77 = arg0_1
        s27 = arg1_1
        s61 = arg3_1
        s87 = arg4_1
        assert_size_stride(arg2_1, (s77, s27), (s27, 1))
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            ps0 = (-1)*(s27 // ((-1)*s87))
            buf0 = empty_strided_cuda(((-1)*(s77 // ((-1)*s61)), 1, (-1)*(s27 // ((-1)*s87)), 1), ((-1)*(s27 // ((-1)*s87)), (s27 // ((-1)*s87))*(s77 // ((-1)*s61)), 1, (s27 // ((-1)*s87))*(s77 // ((-1)*s61))), torch.float32)
            buf3 = empty_strided_cuda(((-1)*(s77 // ((-1)*s61)), 1, (-1)*(s27 // ((-1)*s87)), 1), ((-1)*(s27 // ((-1)*s87)), 1, 1, (-1)*(s27 // ((-1)*s87))), torch.float32)
            # Topologically Sorted Source Nodes: [x_padded, abs_1, amax, x_amax, sf, abs_2, log2, ceil, sf_1], Original ATen: [aten.zeros, aten.view, aten.abs, aten.amax, aten.clamp, aten.div, aten.log2, aten.ceil, aten.pow]
            triton_red_fused_abs_amax_ceil_clamp_div_log2_pow_view_zeros_0_xnumel = (s27 // ((-1)*s87))*(s77 // ((-1)*s61))
            triton_red_fused_abs_amax_ceil_clamp_div_log2_pow_view_zeros_0_r0_numel = s61*s87
            stream0 = get_raw_stream(0)
            triton_red_fused_abs_amax_ceil_clamp_div_log2_pow_view_zeros_0.run(arg2_1, buf0, buf3, s87, ps0, s61, s77, s27, triton_red_fused_abs_amax_ceil_clamp_div_log2_pow_view_zeros_0_xnumel, triton_red_fused_abs_amax_ceil_clamp_div_log2_pow_view_zeros_0_r0_numel, stream=stream0)
            ps1 = (-1)*s87*(s27 // ((-1)*s87))
            ps2 = (-1)*s61*s87*(s27 // ((-1)*s87))
            buf1 = empty_strided_cuda(((-1)*(s77 // ((-1)*s61)), s61, (-1)*(s27 // ((-1)*s87)), s87), ((-1)*s61*s87*(s27 // ((-1)*s87)), (-1)*s87*(s27 // ((-1)*s87)), s87, 1), torch.float8_e4m3fn)
            # Topologically Sorted Source Nodes: [x_padded, abs_1, x_amax, sf, abs_2, log2, ceil, sf_1, truediv_1, mul_2, x_scaled], Original ATen: [aten.zeros, aten.view, aten.clamp, aten.div, aten.abs, aten.log2, aten.ceil, aten.pow, aten.reciprocal, aten.mul, aten._to_copy]
            triton_poi_fused__to_copy_abs_ceil_clamp_div_log2_mul_pow_reciprocal_view_zeros_1_xnumel = s61*s87*(s27 // ((-1)*s87))*(s77 // ((-1)*s61))
            stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_abs_ceil_clamp_div_log2_mul_pow_reciprocal_view_zeros_1.run(arg2_1, buf0, buf1, ps1, s77, s27, ps0, s87, ps2, triton_poi_fused__to_copy_abs_ceil_clamp_div_log2_mul_pow_reciprocal_view_zeros_1_xnumel, stream=stream0)
            del arg2_1
            del buf0
            buf2 = empty_strided_cuda((s77, (-1)*s87*(s27 // ((-1)*s87))), ((-1)*s87*(s27 // ((-1)*s87)), 1), torch.float8_e4m3fn)
            # Topologically Sorted Source Nodes: [x_padded, abs_1, x_amax, sf, abs_2, log2, ceil, sf_1, truediv_1, mul_2, x_scaled, view_as, getitem_2], Original ATen: [aten.zeros, aten.view, aten.clamp, aten.div, aten.abs, aten.log2, aten.ceil, aten.pow, aten.reciprocal, aten.mul, aten._to_copy, aten.slice]
            triton_poi_fused__to_copy_abs_ceil_clamp_div_log2_mul_pow_reciprocal_slice_view_zeros_2_xnumel = (-1)*s87*s77*(s27 // ((-1)*s87))
            stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_abs_ceil_clamp_div_log2_mul_pow_reciprocal_slice_view_zeros_2.run(buf1, buf2, ps1, s27, s61, s77, s87, triton_poi_fused__to_copy_abs_ceil_clamp_div_log2_mul_pow_reciprocal_slice_view_zeros_2_xnumel, stream=stream0)
            del buf1
        return (buf2, reinterpret_tensor(buf3, ((-1)*(s77 // ((-1)*s61)), (-1)*(s27 // ((-1)*s87))), ((-1)*(s27 // ((-1)*s87)), 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = 8192
    arg1_1 = 3072
    arg2_1 = rand_strided((8192, 3072), (3072, 1), device='cuda:0', dtype=torch.float32)
    arg3_1 = 128
    arg4_1 = 128
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat)


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
