// Includes' hash value: 93cdef8b06ca291d2adf245044344b72

#include <deep_gemm/impls/sm100_fp8_fp4_gemm_1d1d.cuh>

using namespace deep_gemm;

static void __instantiate_kernel() {
    auto ptr = reinterpret_cast<void*>(&sm100_fp8_fp4_gemm_1d1d_impl<
        cute::UMMA::Major::K, cute::UMMA::Major::K,
        128, 128,
        0, 3072, 6144,
        112, 128, 128,
        1,
        128, 128, 128,
        9,
        128, 128,
        2, true,
        148,
        1,
        GemmType::Normal, false,
        cutlass::float_e4m3_t, cutlass::float_e4m3_t, cutlass::bfloat16_t,
        epilogue::transform::EpilogueIdentity
    >);
};
