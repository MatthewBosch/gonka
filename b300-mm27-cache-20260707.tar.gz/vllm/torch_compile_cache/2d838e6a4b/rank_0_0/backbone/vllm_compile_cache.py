{   ((1, 32768), 0, 'inductor_standalone'): {   'cache_key': 'amsiqg737mhedh36igttpynr36osrualwciz7zr3l3c47eqchhvr',
                                                'graph_handle': (   'artifact_compile_range_1_32768_subgraph_0',
                                                                    '/root/.cache/vllm/torch_compile_cache/2d838e6a4b/rank_0_0/backbone/artifact_compile_range_1_32768_subgraph_0')},
    ((1, 32768), 1, 'inductor_standalone'): {   'cache_key': 'atyc33ekardoyct5le2aycsmfhfcq56sqce72fngfbosemqrq6ka',
                                                'graph_handle': (   'artifact_compile_range_1_32768_subgraph_1',
                                                                    '/root/.cache/vllm/torch_compile_cache/2d838e6a4b/rank_0_0/backbone/artifact_compile_range_1_32768_subgraph_1')},
    ((1, 32768), 62, 'inductor_standalone'): {   'cache_key': 'a3u2qt6nz7uhqgq37lfmebz5a7aihc7ixeeafcfo75ts4e44r76z',
                                                 'graph_handle': (   'artifact_compile_range_1_32768_subgraph_62',
                                                                     '/root/.cache/vllm/torch_compile_cache/2d838e6a4b/rank_0_0/backbone/artifact_compile_range_1_32768_subgraph_62')}}