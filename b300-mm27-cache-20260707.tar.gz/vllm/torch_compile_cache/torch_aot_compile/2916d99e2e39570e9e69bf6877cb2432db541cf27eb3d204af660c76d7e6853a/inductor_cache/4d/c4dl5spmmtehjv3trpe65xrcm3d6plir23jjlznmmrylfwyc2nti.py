r"""
Compile-time auto-tuning block: 

import torch
from torch._dynamo.testing import rand_strided
from torch._dynamo.utils import preserve_rng_state
from torch._inductor.select_algorithm import AlgorithmSelectorCache
from torch._inductor.async_compile import AsyncCompile

async_compile = AsyncCompile()
generate_example_value = AlgorithmSelectorCache.generate_example_value
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
get_raw_stream = torch._C._cuda_getCurrentRawStream


# kernel path: /root/.cache/vllm/torch_compile_cache/torch_aot_compile/2916d99e2e39570e9e69bf6877cb2432db541cf27eb3d204af660c76d7e6853a/inductor_cache/kp/ckpa5wngnig74qcvk4ld3xbihpsh5ppyfhrqkh6xpa6o7j2cc4cf.py
# Topologically Sorted Source Nodes: [to_1], Original ATen: [aten._to_copy]
# Source node to ATen node mapping:
#   to_1 => convert_element_type
# Graph fragment:
#   %buf9 : Tensor  = PlaceHolder[target=buf9]
#   %convert_element_type : Tensor "f32[s72, 3072][3072, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty_1, torch.float32), kwargs = {})
#   return %convert_element_type
triton_poi_fused__to_copy_0 = async_compile.triton('triton_poi_fused__to_copy_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 134217728}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=148, cc=103, major=10, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'backend_hash': '14902427B4EAA00E03F37BD9A4AC37B803D52FB315473AEC448643748601AB78', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'tiling_scores': {'x': 805306368}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_0(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tl.store(out_ptr0 + (x0), tmp1, xmask)
''', device_str='cuda')

async_compile.wait(globals())
del async_compile

import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
with torch.cuda._DeviceGuard(0):
    stream0 = get_raw_stream(0)
stream0 = get_raw_stream(0)
buf5 = generate_example_value((32768, 3072), (3072, 1), 'cuda:0', torch.bfloat16, 0, (32768, 3072))
buf11 = generate_example_value((32768, 3072), (3072, 1), 'cuda:0', torch.float32, 0, (32768, 3072))
with torch.cuda._DeviceGuard(0):
    triton_poi_fused__to_copy_0.run(buf5, buf11, 100663296, stream=stream0)
del buf5, buf11

"""
# AOT ID: ['63_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /root/.cache/vllm/torch_compile_cache/torch_aot_compile/2916d99e2e39570e9e69bf6877cb2432db541cf27eb3d204af660c76d7e6853a/inductor_cache/kp/ckpa5wngnig74qcvk4ld3xbihpsh5ppyfhrqkh6xpa6o7j2cc4cf.py
# Topologically Sorted Source Nodes: [to_1], Original ATen: [aten._to_copy]
# Source node to ATen node mapping:
#   to_1 => convert_element_type
# Graph fragment:
#   %buf9 : Tensor  = PlaceHolder[target=buf9]
#   %convert_element_type : Tensor "f32[s72, 3072][3072, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty_1, torch.float32), kwargs = {})
#   return %convert_element_type
triton_poi_fused__to_copy_0 = async_compile.triton('triton_poi_fused__to_copy_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 134217728}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=148, cc=103, major=10, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'backend_hash': '14902427B4EAA00E03F37BD9A4AC37B803D52FB315473AEC448643748601AB78', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'tiling_scores': {'x': 805306368}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_0(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tl.store(out_ptr0 + (x0), tmp1, xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1 = args
        args.clear()
        s72 = arg1_1
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            buf0 = empty_strided_cuda((s72, 6144), (6144, 1), torch.float8_e4m3fn)
            buf1 = empty_strided_cuda((s72, 12), (1, 4*((3 + s72) // 4)), torch.int32)
            # Topologically Sorted Source Nodes: [view, per_token_group_fp8_quant_packed], Original ATen: [aten.view, _C.per_token_group_fp8_quant_packed]
            torch.ops._C.per_token_group_fp8_quant_packed.default(reinterpret_tensor(arg0_1, (s72, 6144), (6144, 1), 0), buf0, buf1, 128, 1e-10, -448.0, 448.0)
            del arg0_1
            buf5 = empty_strided_cuda((s72, 3072), (3072, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [fp8_gemm_nt_op], Original ATen: []
            torch.ops.vllm.fp8_gemm_nt_op.default(buf0, buf1, arg3_1, arg4_1, buf5, True)
            del arg3_1
            del arg4_1
            del buf0
            del buf1
            # Topologically Sorted Source Nodes: [], Original ATen: []
            torch.ops._C.fused_add_rms_norm.default(input=buf5, residual=arg6_1, weight=arg5_1, epsilon=1e-06)
            del arg5_1
            buf11 = empty_strided_cuda((s72, 3072), (3072, 1), torch.float32)
            # Topologically Sorted Source Nodes: [to_1], Original ATen: [aten._to_copy]
            triton_poi_fused__to_copy_0_xnumel = 3072*s72
            stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_0.run(buf5, buf11, triton_poi_fused__to_copy_0_xnumel, stream=stream0)
            buf12 = empty_strided_cuda((s72, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [to_1, linear], Original ATen: [aten._to_copy, aten.t, aten.mm]
            extern_kernels.mm(buf11, reinterpret_tensor(arg7_1, (3072, 256), (1, 3072), 0), out=buf12)
            del arg7_1
            del buf11
            # Topologically Sorted Source Nodes: [moe_forward], Original ATen: [vllm.moe_forward]
            buf13 = torch.ops.vllm.moe_forward.default(buf5, buf12, None, None, arg8_1)
            del arg8_1
            del buf12
            del buf5
            buf15 = buf13
            del buf13
            # Topologically Sorted Source Nodes: [], Original ATen: []
            torch.ops._C.fused_add_rms_norm.default(input=buf15, residual=arg6_1, weight=arg9_1, epsilon=1e-06)
            del arg6_1
            del arg9_1
        return (buf15, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((32768, 48, 128), (6144, 128, 1), device='cuda:0', dtype=torch.bfloat16)
    arg1_1 = 32768
    arg2_1 = 32768
    arg3_1 = rand_strided((3072, 6144), (6144, 1), device='cuda:0', dtype=torch.float8_e4m3fn)
    arg4_1 = rand_strided((3072, 12), (1, 3072), device='cuda:0', dtype=torch.int32)
    arg5_1 = rand_strided((3072, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg6_1 = rand_strided((32768, 3072), (3072, 1), device='cuda:0', dtype=torch.bfloat16)
    arg7_1 = rand_strided((256, 3072), (3072, 1), device='cuda:0', dtype=torch.float32)
    import pickle
    global arg8_1
    arg8_1 = pickle.loads(b'\x80\x04\x95U\x00\x00\x00\x00\x00\x00\x00\x8c\x16vllm.utils.torch_utils\x94\x8c\tLayerName\x94\x93\x94)\x81\x94}\x94\x8c\x05value\x94\x8c\x1bmodel.layers.61.mlp.experts\x94sb.')
    arg9_1 = rand_strided((3072, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat)


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
